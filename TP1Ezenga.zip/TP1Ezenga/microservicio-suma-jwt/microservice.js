const express = require('express');
const winston = require('winston');
require('dotenv').config();

const app = express();

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'microservice.log' })
  ]
});

app.get('/random', (req, res) => {
  const num1 = Math.floor(Math.random() * 9) + 1;
  const num2 = Math.floor(Math.random() * 9) + 1;
  logger.info(`Números generados: ${num1}, ${num2}`);
  res.json({ num1, num2 });
});

app.get('/health', (req, res) => {
  logger.info('Solicitud de verificación de estado');
  res.json({
    service: 'Microservicio de números aleatorios',
    status: '10 puntos 🔥👊',
    timestamp: new Date().toISOString()
  });
});

app.use((err, req, res, next) => {
  logger.error(`Error no manejado: ${err.message}`);
  res.status(500).json({ error: 'Error interno del servidor' });
});

const PORT = process.env.PORT2 || 6001;
app.listen(PORT, () => {
  logger.info(`Microservicio iniciado en puerto ${PORT}`);
});