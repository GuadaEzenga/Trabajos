const express = require('express');
const axios = require('axios');
const winston = require('winston');
require('dotenv').config();
const { generateToken, authenticateUser, verifyToken } = require('./auth');

const app = express();
app.use(express.json());

// Configuración del logger
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'combined.log' })
  ]
});

// Endpoint de login
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    logger.error('Faltan credenciales en la solicitud de login');
    return res.status(400).json({ error: 'Faltan credenciales' });
  }

  if (authenticateUser(username, password)) {
    const token = generateToken(username);
    logger.info(`Usuario ${username} autenticado exitosamente`);
    return res.json({
      token,
      message: 'Autenticación exitosa 😀😃',
      expiresIn: '1 hora 😀😃'
    });
  } else {
    logger.error('Credenciales inválidas');
    return res.status(401).json({ error: 'No es x ahi 😡👎' });
  }
});

// Endpoint de suma
app.get('/sum', verifyToken, async (req, res) => {
  try {
    const response = await axios.get(process.env.NUM_SERVICE_URL);
    const { num1, num2 } = response.data;
    const result = num1 + num2;
    logger.info(`Suma realizada: ${num1} + ${num2} = ${result} por usuario ${req.user.username}`);
    res.json({
      result,
      operation: `${num1} + ${num2}`,
      user: req.user.username,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    logger.error(`Error al obtener números aleatorios: ${error.message}`);
    res.status(500).json({ error: 'Error al procesar la suma' });
  }
});

// Endpoint de información
app.get('/info', verifyToken, (req, res) => {
  logger.info(`Información solicitada por usuario ${req.user.username}`);
  res.json({
    service: 'API de suma con autenticación JWT',
    user: req.user.username,
    endpoints: [
      {
        path: '/login',
        method: 'POST',
        description: 'Autenticación de usuario y generación de token'
      },
      {
        path: '/sum',
        method: 'GET',
        description: 'Obtiene dos números aleatorios y devuelve su suma'
      },
      {
        path: '/info',
        method: 'GET',
        description: 'Información sobre la API'
      }
    ]
  });
});

// Manejo de errores centralizado
app.use((err, req, res, next) => {
  logger.error(`Error no manejado: ${err.message}`);
  res.status(500).json({ error: 'Error interno del servidor' });
});

const PORT = process.env.PORT || 6000;
app.listen(PORT, () => {
  logger.info(`Servicio principal iniciado en puerto ${PORT}`);
});