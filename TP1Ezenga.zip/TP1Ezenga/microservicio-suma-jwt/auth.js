const jwt = require('jsonwebtoken');
require('dotenv').config();

const generateToken = (username) => {
  return jwt.sign({ username }, process.env.JWT_SECRET, { expiresIn: '1h' });
};

const authenticateUser = (username, password) => {
  return username === process.env.AUTH_USERNAME && password === process.env.AUTH_PASSWORD;
};

const verifyToken = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'No es x ahi' });
  }

  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    return res.status(401).json({ error: 'No es x ahi (invalido o expiró)' });
  }
};

module.exports = { generateToken, authenticateUser, verifyToken };