const express = require('express');
const speakeasy = require('speakeasy');
const qrcode = require('qrcode');
const qrcodeTerminal = require('qrcode-terminal');
const { saveSecret, getSecret } = require('./database');

const app = express();
const port = 3000;

// Middleware para parsear JSON
app.use(express.json());

// Endpoint: GET /generate-qr
app.get('/generate-qr', async (req, res) => {
    const { email, empresa } = req.query; // Obtener email de los query params

    if (!email) {
        return res.status(400).json({ error: 'Email es requerido' });
    }

    if (!empresa) {
        return res.status(400).json({ error: 'Empresa es requerido' });
    }


    // Generar un nuevo secreto TOTP (20 bytes)
    const secret = speakeasy.generateSecret({
        length: 20,
        name: `app:${email}`,
        issuer: `emp:${empresa}`,
    });

    // Guardar el secreto en la base de datos
    try {
        await saveSecret(email, secret.base32);

        // Generar el código QR
        const qrCodeDataUrl = await qrcode.toDataURL(secret.otpauth_url);
        // Mostrar el código QR en la terminal
        qrcodeTerminal.generate(secret.otpauth_url, { small: true });
        res.status(200).json({
            secret: secret.base32,
            qrcode: qrCodeDataUrl
        });
    } catch (err) {
        res.status(500).json({ error: 'Error al generar el código QR o guardar el secreto' });
    }
});

// Endpoint: POST /verify-totp
app.post('/verify-totp', async (req, res) => {
    const { email, token } = req.body;

    if (!email) {
        return res.status(400).json({ error: 'Email es requerido' });
    }

    if (!token) {
        return res.status(400).json({ error: 'Token no proporcionado' });
    }

    // Obtener el secreto de la base de datos
    try {
        const totpSecret = await getSecret(email);
        if (!totpSecret) {
            return res.status(400).json({ error: 'Secret no definido para este email. Generar QR primero.' });
        }

        // Verificar el token TOTP
        const verified = speakeasy.totp.verify({
            secret: totpSecret,
            encoding: 'base32',
            token: token
        });

        if (verified) {
            res.status(200).json({ message: '🤙🏼🤙🏼🤙🏼🤙🏼' });
        } else {
            res.status(400).json({ message: '👎🏼👎🏼👎🏼👎🏼' });
        }
    } catch (err) {
        res.status(500).json({ error: 'Error al verificar el token' });
    }
});

// Endpoint: GET /generate-totp
app.get('/generate-totp', async (req, res) => {
    const { email } = req.query;

    if (!email) {
        return res.status(400).json({ error: 'Email es requerido' });
    }

    // Obtener el secreto de la base de datos
    try {
        const totpSecret = await getSecret(email);
        if (!totpSecret) {
            return res.status(400).json({ error: 'Secret no definido para este email. Generar QR primero.' });
        }

        // Generar un token TOTP
        const token = speakeasy.totp({
            secret: totpSecret,
            encoding: 'base32'
        });

        res.status(200).json({ token });
    } catch (err) {
        res.status(500).json({ error: 'Error al generar el token' });
    }
});

// Iniciar el servidor
app.listen(port, () => {
    console.log(`Servidor ejecutándose en http://localhost:${port}`);
});