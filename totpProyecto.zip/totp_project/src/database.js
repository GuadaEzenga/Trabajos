const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// Conectar a la base de datos SQLite
const db = new sqlite3.Database(path.join(__dirname, '../db/totp.db'), (err) => {
    if (err) {
        console.error('Error al conectar a la base de datos:', err.message);
    } else {
        console.log('Conectado a la base de datos SQLite');
    }
});

// Crear la tabla users si no existe
db.serialize(() => {
    db.run(`
        CREATE TABLE IF NOT EXISTS users (
            email TEXT PRIMARY KEY,
            totp_secret TEXT NOT NULL
        )
    `, (err) => {
        if (err) {
            console.error('Error al crear la tabla users:', err.message);
        } else {
            console.log('Tabla users creada o ya existe');
        }
    });
});

// Función para guardar un secreto TOTP
function saveSecret(email, secret) {
    return new Promise((resolve, reject) => {
        db.run(
            `INSERT OR REPLACE INTO users (email, totp_secret) VALUES (?, ?)`,
            [email, secret],
            (err) => {
                if (err) {
                    reject(err);
                } else {
                    resolve();
                }
            }
        );
    });
}

// Función para obtener un secreto TOTP por email
function getSecret(email) {
    return new Promise((resolve, reject) => {
        db.get(
            `SELECT totp_secret FROM users WHERE email = ?`,
            [email],
            (err, row) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(row ? row.totp_secret : null);
                }
            }
        );
    });
}

module.exports = { saveSecret, getSecret };
