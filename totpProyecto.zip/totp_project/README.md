# Servidor de Autenticación TOTP

Este repositorio contiene un servidor API REST con Express para implementar autenticación de dos factores (2FA) usando TOTP (Time-based One-Time Password).

## Descripción
Este proyecto implementa un servidor que permite:
- Generar secretos TOTP y códigos QR para configurar aplicaciones autenticadoras
- Verificar tokens TOTP proporcionados por el usuario
- Generar tokens TOTP para pruebas

El sistema utiliza el estándar TOTP, compatible con aplicaciones como Google Authenticator, Microsoft Authenticator, Authy, entre otras. Los secretos TOTP se almacenan en una base de datos SQLite.

## Requisitos previos
- Node.js (versión 14.x o superior)
- npm (gestor de paquetes de Node.js)

## Instalación
1. Clona este repositorio (o navega al directorio):
   ```bash
   cd C:\Users\Guada\Documents\programacion\totp_project

 2. Instala las dependencias:
    npm install

 3. Inicia el servidor:
    node src/index.js
    
    El servidor se ejecutará en http://localhost:3000.